package Macaco;

public class MacacosSeries {
	public static void main(String[] args) {
		Macaco macaco1 = new Macaco ();
		Macaco macaco2 = new Macaco ();

		macaco1.setNome("Miguel");
		macaco2.setNome("Wilian");
		macaco1.setAltura(175);
		macaco2.setPeso(79);
		System.out.println("O nome do macaco 1 e: "+macaco1.getNome());
		System.out.println("O nome do macaco 2 e: "+macaco2.getNome());
		System.out.println("A altura do macaco 1 e: "+macaco1.getAltura());
		System.out.println("O peso do macaco 2 e: "+macaco2.getPeso());
		
	}
}
