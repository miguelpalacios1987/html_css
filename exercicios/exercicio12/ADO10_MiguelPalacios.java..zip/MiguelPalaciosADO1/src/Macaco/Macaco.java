package Macaco;

public class Macaco {
 private int altura;
 private String nome;
private int peso;
private int alturaPular;
private int velocidadCorrer;
 
 public Macaco () {
	 
 }
 
 public void setAltura(int altura) {
	 this.altura = altura;
 }
 public int getAltura() {
	 return altura;
 }
 
 public void setNome(String nome) {
	  this.nome =nome;
 }
 public String getNome () {
	 return nome;
 }

	public void setPeso(int peso) {
		this.peso = peso;
		
	}
	
	public int getPeso() {
		return  peso;
		
	}
	public void pular (int pular) {
		this.alturaPular += 5;
	}
	public void correr (int correr) {
		this.velocidadCorrer += 5;
	}
		// TODO Auto-generated method stub
		
	}
	
	

